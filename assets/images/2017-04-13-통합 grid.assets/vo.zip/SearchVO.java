package com.xxxx.dto;

import java.io.Serializable;

public class SearchVO  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String col;
	private String keyword;
	public String getCol() {
		return col;
	}
	public void setCol(String col) {
		this.col = col;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
}
