package com.xxxx.dto;

import java.io.Serializable;

public class OrderVO  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String orderCol;
	private String orderType;
	public String getOrderCol() {
		return orderCol;
	}
	public void setOrderCol(String orderCol) {
		this.orderCol = orderCol;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
}
