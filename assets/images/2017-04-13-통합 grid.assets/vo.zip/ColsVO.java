package com.xxxx.dto;

import java.io.Serializable;

public class ColsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String colDBNm;
	private String colViewNm;
	private int colWidth;
	
	public String getColDBNm() {
		return colDBNm;
	}
	public void setColDBNm(String colDBNm) {
		this.colDBNm = colDBNm;
	}
	public String getColViewNm() {
		return colViewNm;
	}
	public void setColViewNm(String colViewNm) {
		this.colViewNm = colViewNm;
	}
	public int getColWidth() {
		return colWidth;
	}
	public void setColWidth(int colWidth) {
		this.colWidth = colWidth;
	}
}
