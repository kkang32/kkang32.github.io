package com.xxxx.dto;

import java.io.Serializable;
import java.util.List;

public class PageVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String gid;
	private String pid;
	private int level;
	
	private int page;
	private int listCount;
	private List<SearchVO> search;
	private List<OrderVO> orders;
	
	private List<ColsVO> cols;
	
	
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getListCount() {
		return listCount;
	}
	public void setListCount(int listCount) {
		this.listCount = listCount;
	}
	
	public String getGid() {
		return gid;
	}
	public void setGid(String gid) {
		this.gid = gid;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public List<ColsVO> getCols() {
		return cols;
	}
	public void setCols(List<ColsVO> cols) {
		this.cols = cols;
	}
	public List<OrderVO> getOrders() {
		return orders;
	}
	public void setOrders(List<OrderVO> orders) {
		this.orders = orders;
	}
	public List<SearchVO> getSearch() {
		return search;
	}
	public void setSearch(List<SearchVO> search) {
		this.search = search;
	}
	

}
