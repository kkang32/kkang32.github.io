package com.attic.tmatch;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewFrame;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewListener2;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.Core.MinMaxLocResult;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.SurfaceView;
import android.view.WindowManager;

public class MainActivity extends Activity implements CvCameraViewListener2 {

	private CameraBridgeViewBase mOpenCvCameraView;
	private Mat mSampleMat = null;
	
	
	private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {
        @Override
        public void onManagerConnected(int status) {
            switch (status) {
                case LoaderCallbackInterface.SUCCESS:
                {
                    
                    mOpenCvCameraView.enableView();
                } break;
                default:
                {
                    super.onManagerConnected(status);
                } break;
            }
        }
    };
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		mOpenCvCameraView = (CameraBridgeViewBase) findViewById(R.id.cam);
		mOpenCvCameraView.setVisibility(SurfaceView.VISIBLE);

	    mOpenCvCameraView.setCvCameraViewListener(this);
	    
	    
	   
	    
	 
    	
		
	    
	    
	}

	@Override
    public void onPause()
    {
        super.onPause();
        if (mOpenCvCameraView != null)
            mOpenCvCameraView.disableView();
    }

    @Override
    public void onResume()
    {
        super.onResume();
        OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_2_4_5, this, mLoaderCallback);
    }

    public void onDestroy() {
        super.onDestroy();
        if (mOpenCvCameraView != null)
            mOpenCvCameraView.disableView();
    }
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.		
		return true;
	}

	@Override
	public void onCameraViewStarted(int width, int height) {
		Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.sample);
		mSampleMat = new Mat(bitmap.getWidth(), bitmap.getHeight(), Core.DEPTH_MASK_8U);
		Utils.bitmapToMat(bitmap, mSampleMat);
	}

	@Override
	public void onCameraViewStopped() {
		// TODO Auto-generated method stub		
	}

	@Override
	public Mat onCameraFrame(CvCameraViewFrame inputFrame) {
		// TODO Auto-generated method stub
		
		
		//Mat camMat = new Mat(inputFrame.rgba().width(), inputFrame.rgba().height(), CvType.);
		Mat camMat = inputFrame.rgba();
		//Imgproc.cvtColor(inputFrame.rgba(), camMat, Imgproc.COLOR_BGRA2GRAY);  
		
		Mat retval = new Mat(camMat.width() - mSampleMat.width() + 1, camMat.height() - mSampleMat.height() + 1, CvType.CV_32F);
		
		Imgproc.matchTemplate(camMat, mSampleMat, retval, Imgproc.TM_CCOEFF_NORMED);
		MinMaxLocResult res = Core.minMaxLoc(retval);
		if (res.maxVal > 0.6f){
			Point p = new Point(res.maxLoc.x + mSampleMat.width(), res.maxLoc.y + mSampleMat.height());
			Scalar s = new Scalar(255,0,0);
			Core.rectangle(camMat, res.maxLoc, p, s, 5);
			
		}
		Log.e("������", res.maxVal  + "," + res.minVal);
		return camMat;
	}

}
